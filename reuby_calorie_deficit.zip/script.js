function calculateDeficit() {
    let weight = document.getElementById("weight").value;
    let height = document.getElementById("height").value;
    let age = document.getElementById("age").value;
    let activity = document.getElementById("activity").value;

    if (!weight || !height || !age) {
        document.getElementById("result").innerHTML = "Please fill in all fields.";
        return;
    }

    // Calculate BMR (Mifflin-St Jeor Formula)
    let BMR = (10 * weight) + (6.25 * height) - (5 * age) + 5;
    let maintenanceCalories = BMR * activity;
    let deficitCalories = maintenanceCalories - 500; // 500 kcal deficit for ~0.5kg weekly loss

    document.getElementById("result").innerHTML = 
        `Your maintenance calories: <b>${Math.round(maintenanceCalories)} kcal/day</b><br>
        To lose weight: <b>${Math.round(deficitCalories)} kcal/day</b>`;
}
